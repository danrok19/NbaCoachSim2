module com.example.kckgmv2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires lanterna;


    opens com.example.kckgmv2 to javafx.fxml;
    exports com.example.kckgmv2;
    exports com.example.kckgmv2.controller;
    opens com.example.kckgmv2.controller to javafx.fxml;
}