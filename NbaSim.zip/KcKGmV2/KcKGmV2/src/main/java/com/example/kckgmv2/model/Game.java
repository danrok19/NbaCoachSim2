package com.example.kckgmv2.model;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.Random;

public class Game {
    private String myTeam;
    private String oppTeam;
    private Team myTeamT;
    private Team oppTeamT;
    private int myScore=0;
    private int oppScore=0;
    private int qtr=1;
    private int minute = 12;
    private Squad mySquad;
    private Squad oppSquad;
    private Bench myBench;
    private Bench oppBench;
    private History historia;
    private int licznik = 0;
    private boolean isEnd = false;

    public void setGame(Game game){
        this.myTeam = game.myTeam;
        this.oppTeam = game.oppTeam;
        this.myTeamT = game.myTeamT;
        this.oppTeamT = game.oppTeamT;
        this.myScore = game.myScore;
        this.oppScore = game.oppScore;
        this.qtr = game.qtr;
        this.minute = game.minute;
        this.mySquad = game.mySquad;
        this.oppSquad = game.oppSquad;
        this.myBench = game.myBench;
        this.oppBench = game.oppBench;
        this.licznik = game.licznik;
        this.isEnd = game.isEnd;
    }

    public void setGame(List<Integer> integers){
        switch (integers.get(0)){
            case 1:
                setMyTeam("Brooklyn Nets");
                setMyTeamT("Brooklyn Nets");
                break;
            case 2:
                setMyTeam("Boston Celtics");
                setMyTeamT("Boston Celtics");
                break;
            case 3:
                setMyTeam("Philadelphia 76ers");
                setMyTeamT("Philadelphia 76ers");
                break;
            case 4:
                setMyTeam("Toronto Raptors");
                setMyTeamT("Toronto Raptors");
                break;
            case 5:
                setMyTeam("New York Knicks");
                setMyTeamT("New York Knicks");
                break;

        }
        switch (integers.get(1)){
            case 1:
                setOppTeam("Brooklyn Nets");
                setOppTeamT("Brooklyn Nets");
                break;
            case 2:
                setOppTeam("Boston Celtics");
                setOppTeamT("Boston Celtics");
                break;
            case 3:
                setOppTeam("Philadelphia 76ers");
                setOppTeamT("Philadelphia 76ers");
                break;
            case 4:
                setOppTeam("Toronto Raptors");
                setOppTeamT("Toronto Raptors");
                break;
            case 5:
                setOppTeam("New York Knicks");
                setOppTeamT("New York Knicks");
                break;

        }

//        setMySquad(new Squad(getMyTeamT().getPlayers().get(0),getMyTeamT().getPlayers().get(1),getMyTeamT().getPlayers().get(2),getMyTeamT().getPlayers().get(3),getMyTeamT().getPlayers().get(4)));
//        setOppSquad(new Squad(getOppTeamT().getPlayers().get(0),getOppTeamT().getPlayers().get(1),getOppTeamT().getPlayers().get(2),getOppTeamT().getPlayers().get(3),getOppTeamT().getPlayers().get(4)));
        this.mySquad = new Squad(myTeamT.getPlayers().get(0),myTeamT.getPlayers().get(1),myTeamT.getPlayers().get(2),myTeamT.getPlayers().get(3),myTeamT.getPlayers().get(4));
        this.oppSquad = new Squad(oppTeamT.getPlayers().get(0),oppTeamT.getPlayers().get(1),oppTeamT.getPlayers().get(2),oppTeamT.getPlayers().get(3),oppTeamT.getPlayers().get(4));
        this.myBench = new Bench(myTeamT.getPlayers().get(5),myTeamT.getPlayers().get(6),myTeamT.getPlayers().get(7));
        this.oppBench = new Bench(oppTeamT.getPlayers().get(5),oppTeamT.getPlayers().get(6),oppTeamT.getPlayers().get(7));


    }

    public void setMyTeam(String myTeam){
        this.myTeam = myTeam;
    }
    public void setOppTeam(String oppTeam){
        this.oppTeam = oppTeam;
    }
    public void setMyTeamT(String myTeam){
        this.myTeamT = new Team(myTeam);
        System.out.println("to jest myTeam: "+this.myTeamT.getName());
    }
    public void setOppTeamT(String oppTeam){
        this.oppTeamT = new Team(oppTeam);
        System.out.println("to jest oppTeam: "+this.oppTeamT.getName());
    }
    public String getMyTeam(){
        return this.myTeam;
    }
    public String getOppTeam(){
        return this.oppTeam;
    }

    public Team getMyTeamT(){
        return this.myTeamT;
    }
    public Team getOppTeamT(){
        return this.oppTeamT;
    }

    public void setMySquad(Squad squad){
        this.mySquad = squad;
    }

    public Squad getMySquad(){
        return this.mySquad;
    }

    public void setOppSquad(Squad squad){
        this.oppSquad = squad;
    }

    public Squad getOppSquad(){
        return this.oppSquad;
    }

    public int getMyScore(){
        return this.myScore;
    }
    public int getOppScore(){
        return this.oppScore;
    }
    public void setMyScore(int score){
        this.myScore = score;
    }
    public void setOppScore(int score){
        this.oppScore = score;
    }

    public int getMinute(){
        return this.minute;
    }
    public int getQtr(){
        return this.qtr;
    }

    public Bench getMyBench(){
        return this.myBench;
    }
    public Bench getOppBench(){
        return this.oppBench;
    }

    public void runGame() {
        if (minute == 0 && qtr < 4) {
            qtr++;
            minute = 12;
        } else if (minute == 0 && qtr == 4) {
            licznik++;
            if(licznik < 2) {
                String string="\n"+this.myTeam +" "+ this.myScore + " : "+ this.oppScore +" "+ this.oppTeam;
                try {
                    Files.write(Paths.get("SaveScore.txt"), string.getBytes(), StandardOpenOption.APPEND);
                }catch (IOException e) {
                    //exception handling left as an exercise for the reader
                }
            }
            this.isEnd = true;
        } else {
            minute--;

            mySquad.updateOverall();
            oppSquad.updateOverall();
            myBench.addCondition();
            oppBench.addCondition();

            Random rand = new Random();
            int mySquadPower = mySquad.getOverall();
            int oppSquadPower = oppSquad.getOverall();
            int difference = mySquadPower - oppSquadPower;
            if (difference > 20) {
                difference = 20;
            }
            int howMany = rand.nextInt(3) + 2;
            for (int i = 0; i < howMany; i++) {
                Matchup matchup;
                int chance = rand.nextInt(100) + 1;
                Player player1;
                Player player2;
                int myMatchPlayer = rand.nextInt(5) + 1;
                switch (myMatchPlayer) {
                    case 1:
                        player1 = mySquad.getPlayer1();
                        break;
                    case 2:
                        player1 = mySquad.getPlayer2();
                        break;
                    case 3:
                        player1 = mySquad.getPlayer3();
                        break;
                    case 4:
                        player1 = mySquad.getPlayer4();
                        break;
                    case 5:
                        player1 = mySquad.getPlayer5();
                        break;
                    default:
                        player1 = mySquad.getPlayer1();
                }
                int oppMatchPlayer = rand.nextInt(5) + 1;
                switch (oppMatchPlayer) {
                    case 1:
                        player2 = oppSquad.getPlayer1();
                        break;
                    case 2:
                        player2 = oppSquad.getPlayer2();
                        break;
                    case 3:
                        player2 = oppSquad.getPlayer3();
                        break;
                    case 4:
                        player2 = oppSquad.getPlayer4();
                        break;
                    case 5:
                        player2 = oppSquad.getPlayer5();
                        break;
                    default:
                        player2 = oppSquad.getPlayer1();
                }
                if (chance < 50 + difference) {
                    matchup = new Matchup(player1, player2);
                    myScore += matchup.getPoints();

                } else {
                    matchup = new Matchup(player2, player1);
                    oppScore += matchup.getPoints();
                }

            }

        }
    }
}
