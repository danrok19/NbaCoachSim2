package com.example.kckgmv2.model;

public class Change {
    private Team team;
    private Squad squad;
    private Player playerIn;
    private Player playerOut;
    private Bench bench;

    public Change(Team _team, Squad _squad, Bench _bench){
        this.team = _team;
        this.squad = _squad;
        this.bench = _bench;

    }

    public void setPlayerOut(Player playerOut){
        this.playerOut = playerOut;
    }
    public void setPlayerIn(Player playerIn){
        this.playerIn = playerIn;
    }

    public void makeChange(){
        if (playerIn == null || playerOut == null) {

        } else {
            squad.changePlayer(playerIn, playerOut);
            bench.changePlayer(playerOut, playerIn);
        }
    }
}
