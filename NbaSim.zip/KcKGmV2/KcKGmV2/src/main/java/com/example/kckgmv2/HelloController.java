package com.example.kckgmv2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import v1.src.main.java.org.example.Main;

import java.io.IOException;

public class HelloController {
    @FXML
    private Label welcomeText;

    @FXML
    private ImageView welcomeImage;
    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Witamy w NBAGm!");
    }
    @FXML
    private Button btn1;

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    protected void switchToLogWindow(ActionEvent event) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("logWindow-view.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private Button exitMode;
    @FXML
    protected void switchMode() throws IOException, InterruptedException {
        Main.main(null);
        exitMode.getScene().getWindow().hide();
    }
}