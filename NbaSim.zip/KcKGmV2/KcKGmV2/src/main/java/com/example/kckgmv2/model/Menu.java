package com.example.kckgmv2.model;

import java.util.List;

public class Menu {
    private String myTeam = "";
    private String oppTeam = "";
    private History historia;
    private List<String> historyList = null;
    private int counterHistory = 0;

    public void setMyTeam(String myTeam){
        this.myTeam = myTeam;
    }

    public void setOppTeam(String oppTeam){
        this.oppTeam = oppTeam;
    }

    public void setHistoria(History historia){
        this.historia = historia;
    }

    public String getMyTeam(){
        return this.myTeam;
    }

    public String getOppTeam(){
        return this.oppTeam;
    }
}
