package com.example.kckgmv2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

public class HistoryController implements Initializable {
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        init();
    }

    @FXML
    private Label historyLabel;
    private String data="";
    private void init(){
        try {
                File myObj = new File("SaveScore.txt");
                Scanner myReader = new Scanner(myObj);
                data="";
                while (myReader.hasNextLine()) {
                    data = data + myReader.nextLine();
                    data = data + "\n";
                    System.out.println(data);
                }
                System.out.println("success");
                myReader.close();
            } catch (FileNotFoundException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        historyLabel.setText(data);
    }
    @FXML
    private Button menuButton;

    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        menuButton.getScene().getWindow().hide();
    }


}


