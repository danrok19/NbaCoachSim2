package com.example.kckgmv2;

import com.example.kckgmv2.model.Game;
import com.example.kckgmv2.model.Squad;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;


public class GameController implements Initializable{
    private Game game;
    List<Integer> integers;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        init();
    }


    public GameController() throws IOException {
        this.game = new Game();
        odczytPlikuTekstowego();
        this.game.setGame(integers);
    }

    public void setGame(Game game){
        this.game = game;
    }
    private void init() {
        myTeamLabel.setText(this.game.getMyTeamT().getName());
        oopTeamLabel.setText(this.game.getOppTeamT().getName());
        myScore.setText(String.valueOf(this.game.getMyScore()));
        oppScore.setText(String.valueOf(this.game.getOppScore()));

        myPlayer1.setText(this.game.getMySquad().getPlayer1().getName() + " " + this.game.getMySquad().getPlayer1().getSurname()+ " " +this.game.getMySquad().getPlayer1().getCondition());
        myPlayer2.setText(this.game.getMySquad().getPlayer2().getName() + " " + this.game.getMySquad().getPlayer2().getSurname()+ " " +this.game.getMySquad().getPlayer2().getCondition());
        myPlayer3.setText(this.game.getMySquad().getPlayer3().getName() + " " + this.game.getMySquad().getPlayer3().getSurname()+ " " +this.game.getMySquad().getPlayer3().getCondition());
        myPlayer4.setText(this.game.getMySquad().getPlayer4().getName() + " " + this.game.getMySquad().getPlayer4().getSurname()+ " " +this.game.getMySquad().getPlayer4().getCondition());
        myPlayer5.setText(this.game.getMySquad().getPlayer5().getName() + " " + this.game.getMySquad().getPlayer5().getSurname()+ " " +this.game.getMySquad().getPlayer5().getCondition());

        oppPlayer1.setText(this.game.getOppSquad().getPlayer1().getName() + " " + this.game.getOppSquad().getPlayer1().getSurname()+ " "+this.game.getOppSquad().getPlayer1().getCondition());
        oppPlayer2.setText(this.game.getOppSquad().getPlayer2().getName() + " " + this.game.getOppSquad().getPlayer2().getSurname()+ " "+this.game.getOppSquad().getPlayer2().getCondition());
        oppPlayer3.setText(this.game.getOppSquad().getPlayer3().getName() + " " + this.game.getOppSquad().getPlayer3().getSurname()+ " "+this.game.getOppSquad().getPlayer3().getCondition());
        oppPlayer4.setText(this.game.getOppSquad().getPlayer4().getName() + " " + this.game.getOppSquad().getPlayer4().getSurname()+ " "+this.game.getOppSquad().getPlayer4().getCondition());
        oppPlayer5.setText(this.game.getOppSquad().getPlayer5().getName() + " " + this.game.getOppSquad().getPlayer5().getSurname()+ " "+this.game.getOppSquad().getPlayer5().getCondition());


        playerLabel1.setText("("+this.game.getMyTeamT().getPlayers().get(0).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(0).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(0).getName() + " " + this.game.getMyTeamT().getPlayers().get(0).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(0).getPoints()+" pkt.");
        playerLabel2.setText("("+this.game.getMyTeamT().getPlayers().get(1).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(1).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(1).getName() + " " + this.game.getMyTeamT().getPlayers().get(1).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(1).getPoints()+" pkt.");
        playerLabel3.setText("("+this.game.getMyTeamT().getPlayers().get(2).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(2).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(2).getName() + " " + this.game.getMyTeamT().getPlayers().get(2).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(2).getPoints()+" pkt.");
        playerLabel4.setText("("+this.game.getMyTeamT().getPlayers().get(3).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(3).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(3).getName() + " " + this.game.getMyTeamT().getPlayers().get(3).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(3).getPoints()+" pkt.");
        playerLabel5.setText("("+this.game.getMyTeamT().getPlayers().get(4).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(4).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(4).getName() + " " + this.game.getMyTeamT().getPlayers().get(4).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(4).getPoints()+" pkt.");
        playerLabel6.setText("("+this.game.getMyTeamT().getPlayers().get(5).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(5).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(5).getName() + " " + this.game.getMyTeamT().getPlayers().get(5).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(5).getPoints()+" pkt.");
        playerLabel7.setText("("+this.game.getMyTeamT().getPlayers().get(6).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(6).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(6).getName() + " " + this.game.getMyTeamT().getPlayers().get(6).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(6).getPoints()+" pkt.");
        playerLabel8.setText("("+this.game.getMyTeamT().getPlayers().get(7).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(7).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(7).getName() + " " + this.game.getMyTeamT().getPlayers().get(7).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(7).getPoints()+" pkt.");


        playerLabel01.setText("("+this.game.getOppTeamT().getPlayers().get(0).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(0).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(0).getName() + " " + this.game.getOppTeamT().getPlayers().get(0).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(0).getPoints()+" pkt.");
        playerLabel02.setText("("+this.game.getOppTeamT().getPlayers().get(1).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(1).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(1).getName() + " " + this.game.getOppTeamT().getPlayers().get(1).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(1).getPoints()+" pkt.");
        playerLabel03.setText("("+this.game.getOppTeamT().getPlayers().get(2).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(2).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(2).getName() + " " + this.game.getOppTeamT().getPlayers().get(2).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(2).getPoints()+" pkt.");
        playerLabel04.setText("("+this.game.getOppTeamT().getPlayers().get(3).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(3).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(3).getName() + " " + this.game.getOppTeamT().getPlayers().get(3).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(3).getPoints()+" pkt.");
        playerLabel05.setText("("+this.game.getOppTeamT().getPlayers().get(4).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(4).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(4).getName() + " " + this.game.getOppTeamT().getPlayers().get(4).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(4).getPoints()+" pkt.");
        playerLabel06.setText("("+this.game.getOppTeamT().getPlayers().get(5).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(5).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(5).getName() + " " + this.game.getOppTeamT().getPlayers().get(5).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(5).getPoints()+" pkt.");
        playerLabel07.setText("("+this.game.getOppTeamT().getPlayers().get(6).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(6).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(6).getName() + " " + this.game.getOppTeamT().getPlayers().get(6).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(6).getPoints()+" pkt.");
        playerLabel08.setText("("+this.game.getOppTeamT().getPlayers().get(7).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(7).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(7).getName() + " " + this.game.getOppTeamT().getPlayers().get(7).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(7).getPoints()+" pkt.");
    }

    @FXML
    private Label myPlayer1;
    @FXML
    private Label myPlayer2;
    @FXML
    private Label myPlayer3;
    @FXML
    private Label myPlayer4;
    @FXML
    private Label myPlayer5;
    @FXML
    private Label oppPlayer1;
    @FXML
    private Label oppPlayer2;
    @FXML
    private Label oppPlayer3;
    @FXML
    private Label oppPlayer4;
    @FXML
    private Label oppPlayer5;

    @FXML
    public Label myTeamLabel;

    @FXML
    public Label oopTeamLabel;

    @FXML
    private Label myScore;
    @FXML
    private Label oppScore;

    @FXML
    private Label playerLabel1;
    @FXML
    private Label playerLabel2;
    @FXML
    private Label playerLabel3;
    @FXML
    private Label playerLabel4;
    @FXML
    private Label playerLabel5;
    @FXML
    private Label playerLabel6;
    @FXML
    private Label playerLabel7;
    @FXML
    private Label playerLabel8;

    @FXML
    private Label playerLabel01;
    @FXML
    private Label playerLabel02;
    @FXML
    private Label playerLabel03;
    @FXML
    private Label playerLabel04;
    @FXML
    private Label playerLabel05;
    @FXML
    private Label playerLabel06;
    @FXML
    private Label playerLabel07;
    @FXML
    private Label playerLabel08;

    @FXML
    private Button nextMinute;

    @FXML
    private Label timeLabel;
    @FXML
    private Label quaterLabel;


    public void nextMinuteGame(){
        this.game.runGame();
        myScore.setText(String.valueOf(this.game.getMyScore()));
        oppScore.setText(String.valueOf(this.game.getOppScore()));
        timeLabel.setText(String.valueOf(this.game.getMinute()) + ":00");
        quaterLabel.setText("Qtr: "+String.valueOf(this.game.getQtr()));

        myPlayer1.setText(this.game.getMySquad().getPlayer1().getName() + " " + this.game.getMySquad().getPlayer1().getSurname()+ " " +this.game.getMySquad().getPlayer1().getCondition());
        myPlayer2.setText(this.game.getMySquad().getPlayer2().getName() + " " + this.game.getMySquad().getPlayer2().getSurname()+ " " +this.game.getMySquad().getPlayer2().getCondition());
        myPlayer3.setText(this.game.getMySquad().getPlayer3().getName() + " " + this.game.getMySquad().getPlayer3().getSurname()+ " " +this.game.getMySquad().getPlayer3().getCondition());
        myPlayer4.setText(this.game.getMySquad().getPlayer4().getName() + " " + this.game.getMySquad().getPlayer4().getSurname()+ " " +this.game.getMySquad().getPlayer4().getCondition());
        myPlayer5.setText(this.game.getMySquad().getPlayer5().getName() + " " + this.game.getMySquad().getPlayer5().getSurname()+ " " +this.game.getMySquad().getPlayer5().getCondition());

        oppPlayer1.setText(this.game.getOppSquad().getPlayer1().getName() + " " + this.game.getOppSquad().getPlayer1().getSurname()+ " "+this.game.getOppSquad().getPlayer1().getCondition());
        oppPlayer2.setText(this.game.getOppSquad().getPlayer2().getName() + " " + this.game.getOppSquad().getPlayer2().getSurname()+ " "+this.game.getOppSquad().getPlayer2().getCondition());
        oppPlayer3.setText(this.game.getOppSquad().getPlayer3().getName() + " " + this.game.getOppSquad().getPlayer3().getSurname()+ " "+this.game.getOppSquad().getPlayer3().getCondition());
        oppPlayer4.setText(this.game.getOppSquad().getPlayer4().getName() + " " + this.game.getOppSquad().getPlayer4().getSurname()+ " "+this.game.getOppSquad().getPlayer4().getCondition());
        oppPlayer5.setText(this.game.getOppSquad().getPlayer5().getName() + " " + this.game.getOppSquad().getPlayer5().getSurname()+ " "+this.game.getOppSquad().getPlayer5().getCondition());

        playerLabel1.setText("("+this.game.getMyTeamT().getPlayers().get(0).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(0).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(0).getName() + " " + this.game.getMyTeamT().getPlayers().get(0).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(0).getPoints()+" pkt.");
        playerLabel2.setText("("+this.game.getMyTeamT().getPlayers().get(1).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(1).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(1).getName() + " " + this.game.getMyTeamT().getPlayers().get(1).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(1).getPoints()+" pkt.");
        playerLabel3.setText("("+this.game.getMyTeamT().getPlayers().get(2).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(2).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(2).getName() + " " + this.game.getMyTeamT().getPlayers().get(2).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(2).getPoints()+" pkt.");
        playerLabel4.setText("("+this.game.getMyTeamT().getPlayers().get(3).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(3).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(3).getName() + " " + this.game.getMyTeamT().getPlayers().get(3).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(3).getPoints()+" pkt.");
        playerLabel5.setText("("+this.game.getMyTeamT().getPlayers().get(4).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(4).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(4).getName() + " " + this.game.getMyTeamT().getPlayers().get(4).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(4).getPoints()+" pkt.");
        playerLabel6.setText("("+this.game.getMyTeamT().getPlayers().get(5).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(5).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(5).getName() + " " + this.game.getMyTeamT().getPlayers().get(5).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(5).getPoints()+" pkt.");
        playerLabel7.setText("("+this.game.getMyTeamT().getPlayers().get(6).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(6).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(6).getName() + " " + this.game.getMyTeamT().getPlayers().get(6).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(6).getPoints()+" pkt.");
        playerLabel8.setText("("+this.game.getMyTeamT().getPlayers().get(7).getAttackOvr()+", "+this.game.getMyTeamT().getPlayers().get(7).getDefenseOvr()+")"+this.game.getMyTeamT().getPlayers().get(7).getName() + " " + this.game.getMyTeamT().getPlayers().get(7).getSurname()
                + ": " + this.game.getMyTeamT().getPlayers().get(7).getPoints()+" pkt.");


        playerLabel01.setText("("+this.game.getOppTeamT().getPlayers().get(0).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(0).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(0).getName() + " " + this.game.getOppTeamT().getPlayers().get(0).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(0).getPoints()+" pkt.");
        playerLabel02.setText("("+this.game.getOppTeamT().getPlayers().get(1).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(1).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(1).getName() + " " + this.game.getOppTeamT().getPlayers().get(1).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(1).getPoints()+" pkt.");
        playerLabel03.setText("("+this.game.getOppTeamT().getPlayers().get(2).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(2).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(2).getName() + " " + this.game.getOppTeamT().getPlayers().get(2).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(2).getPoints()+" pkt.");
        playerLabel04.setText("("+this.game.getOppTeamT().getPlayers().get(3).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(3).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(3).getName() + " " + this.game.getOppTeamT().getPlayers().get(3).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(3).getPoints()+" pkt.");
        playerLabel05.setText("("+this.game.getOppTeamT().getPlayers().get(4).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(4).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(4).getName() + " " + this.game.getOppTeamT().getPlayers().get(4).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(4).getPoints()+" pkt.");
        playerLabel06.setText("("+this.game.getOppTeamT().getPlayers().get(5).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(5).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(5).getName() + " " + this.game.getOppTeamT().getPlayers().get(5).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(5).getPoints()+" pkt.");
        playerLabel07.setText("("+this.game.getOppTeamT().getPlayers().get(6).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(6).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(6).getName() + " " + this.game.getOppTeamT().getPlayers().get(6).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(6).getPoints()+" pkt.");
        playerLabel08.setText("("+this.game.getOppTeamT().getPlayers().get(7).getAttackOvr()+", "+this.game.getOppTeamT().getPlayers().get(7).getDefenseOvr()+")"+this.game.getOppTeamT().getPlayers().get(7).getName() + " " + this.game.getOppTeamT().getPlayers().get(7).getSurname()
                + ": " + this.game.getOppTeamT().getPlayers().get(7).getPoints()+" pkt.");

    }

    public void odczytPlikuTekstowego() throws IOException {
        integers = Files.lines(Paths.get("Game.txt"))
                .map(Integer::parseInt)
                .collect(Collectors.toList());

    }

    public void change(){
    }


    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    protected void switchToMenu(ActionEvent event) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("menu-view.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private Button myChangeButton;

    @FXML
    private Button oppChangeButton;
    @FXML
    public void showBench(){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("change-view.fxml"));
            Parent root = loader.load();

            //The following both lines are the only addition we need to pass the arguments
            ChangeController controller2 = loader.getController();
            controller2.setGame(this.game);
            controller2.pickTeam(this.game.getMyTeamT());
            controller2.setControllerBack(this);

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Changing Menu");
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @FXML
    public void showBench1(){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("change-view.fxml"));
            Parent root = loader.load();

            //The following both lines are the only addition we need to pass the arguments
            ChangeController controller2 = loader.getController();
            controller2.setGame(this.game);
            controller2.pickTeam(this.game.getOppTeamT());
            controller2.setControllerBack(this);

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Changing Menu");
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

//    public void updateGame(){
//        init();
//    }
}
