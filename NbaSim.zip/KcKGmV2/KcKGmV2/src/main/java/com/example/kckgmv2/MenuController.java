package com.example.kckgmv2;

import com.example.kckgmv2.model.Menu;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

public class MenuController{
    private Stage stage;
    private Scene scene;
    private Parent root;
    private Menu menuModel;
    public MenuController(){
        this.menuModel = new Menu();
    }

    public void switchToLogWindow(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("logWindow-view.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void startMatch(ActionEvent event) throws IOException {
        if(menuModel.getMyTeam() != "" && menuModel.getOppTeam() != ""){
            zapisPliku();

            root = FXMLLoader.load(getClass().getResource("game-view.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }

    }


    Image imageBrooklyn = new Image("brooklyn.png");
    Image imageBoston = new Image("boston.png");
    Image imagePhiladelphia = new Image("philadelphia.png");
    Image imageToronto = new Image("toronto.png");
    Image imageKnicks = new Image("knicks.png");
    @FXML
    private ImageView myImageView = new ImageView();

    @FXML
    private ImageView oppImageView;
    //buttony myTeam
    public void chooseMyTeamBrooklyn(ActionEvent event) throws IOException{
        menuModel.setMyTeam("Brooklyn Nets");
        myImageView.setImage(imageBrooklyn);
    }
    public void chooseMyTeamBoston(ActionEvent event) throws IOException{
        menuModel.setMyTeam("Boston Celtics");
        myImageView.setImage(imageBoston);
    }
    public void chooseMyTeam76ers(ActionEvent event) throws IOException{
        menuModel.setMyTeam("Philadelphia 76ers");
        myImageView.setImage(imagePhiladelphia);
    }
    public void chooseMyTeamToronto(ActionEvent event) throws IOException{
        menuModel.setMyTeam("Toronto Raptors");
        myImageView.setImage(imageToronto);
    }
    public void chooseMyTeamKnicks(ActionEvent event) throws IOException{
        menuModel.setMyTeam("New York Knicks");
        myImageView.setImage(imageKnicks);
    }

    //buttony oppTeam
    public void chooseOppTeamBrooklyn(ActionEvent event) throws IOException{
        menuModel.setOppTeam("Brooklyn Nets");
        oppImageView.setImage(imageBrooklyn);
    }
    public void chooseOppTeamBoston(ActionEvent event) throws IOException{
        menuModel.setOppTeam("Boston Celtics");
        oppImageView.setImage(imageBoston);
    }
    public void chooseOppTeam76ers(ActionEvent event) throws IOException{
        menuModel.setOppTeam("Philadelphia 76ers");
        oppImageView.setImage(imagePhiladelphia);
    }
    public void chooseOppTeamToronto(ActionEvent event) throws IOException{
        menuModel.setOppTeam("Toronto Raptors");
        oppImageView.setImage(imageToronto);
    }
    public void chooseOppTeamKnicks(ActionEvent event) throws IOException{
        menuModel.setOppTeam("New York Knicks");
        oppImageView.setImage(imageKnicks);
    }


    public void zapisPliku() throws IOException {

        try {
            PrintWriter fileout = new PrintWriter(new FileWriter("Game.txt"));
            switch (menuModel.getMyTeam()){
                case "Brooklyn Nets":
                    fileout.println(1);
                    break;
                case "Boston Celtics":
                    fileout.println(2);
                    break;
                case "Philadelphia 76ers":
                    fileout.println(3);
                    break;
                case "Toronto Raptors":
                    fileout.println(4);
                    break;
                case "New York Knicks":
                    fileout.println(5);
                    break;
            }
            switch (menuModel.getOppTeam()){
                case "Brooklyn Nets":
                    fileout.println(1);
                    break;
                case "Boston Celtics":
                    fileout.println(2);
                    break;
                case "Philadelphia 76ers":
                    fileout.println(3);
                    break;
                case "Toronto Raptors":
                    fileout.println(4);
                    break;
                case "New York Knicks":
                    fileout.println(5);
                    break;
            }
            fileout.println(0);
            fileout.close();
            System.out.println("success...");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @FXML
    private Button historyButton;

    private String data = "";
    private boolean show= false;
    @FXML
    public void showHistory(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("history-view.fxml"));

        Stage stage = new Stage();
        stage.initOwner(historyButton.getScene().getWindow());
        stage.setScene(new Scene((Parent) loader.load()));

        // showAndWait will block execution until the window closes...
        stage.showAndWait();

        HistoryController controller = loader.getController();
    }

}
