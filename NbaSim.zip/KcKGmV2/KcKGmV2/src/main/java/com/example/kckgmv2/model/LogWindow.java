package com.example.kckgmv2.model;

public class LogWindow {
    History historia = new History();
}
