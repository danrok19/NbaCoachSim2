package com.example.kckgmv2;


import com.example.kckgmv2.model.Change;
import com.example.kckgmv2.model.Game;
import com.example.kckgmv2.model.Team;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ChangeController {
    private Game game;
    private Change change;
    private Team team;
    private GameController gameController;

    public void setGame(Game game) {
        this.game = game;
    }
    public void pickTeam(Team team){
        this.team = team;
        setLabels();
        if(this.team.getName() == this.game.getMyTeamT().getName()){
            this.change = new Change(this.team, this.game.getMySquad(),this.game.getMyBench());
        }
        else{
            this.change = new Change(this.team, this.game.getOppSquad(),this.game.getOppBench());
        }
    }

    public void setControllerBack(GameController gameController){
        this.gameController = gameController;
    }

    @FXML
    private Label bench1;
    @FXML
    private Label bench2;
    @FXML
    private Label bench3;

    @FXML
    private Label squad1;
    @FXML
    private Label squad2;
    @FXML
    private Label squad3;
    @FXML
    private Label squad4;
    @FXML
    private Label squad5;

    public void setLabels(){
        if(this.team.getName() == this.game.getMyTeamT().getName()){
            bench1.setText(this.game.getMyBench().getPlayer1().getName() + " " + this.game.getMyBench().getPlayer1().getSurname() + ": " + this.game.getMyBench().getPlayer1().getCondition());
            bench2.setText(this.game.getMyBench().getPlayer2().getName() + " " + this.game.getMyBench().getPlayer2().getSurname() + ": " + this.game.getMyBench().getPlayer2().getCondition());
            bench3.setText(this.game.getMyBench().getPlayer3().getName() + " " + this.game.getMyBench().getPlayer3().getSurname() + ": " + this.game.getMyBench().getPlayer3().getCondition());

            squad1.setText(this.game.getMySquad().getPlayer1().getName() + " "+ this.game.getMySquad().getPlayer1().getSurname() + ": "+ this.game.getMySquad().getPlayer1().getCondition());
            squad2.setText(this.game.getMySquad().getPlayer2().getName() + " "+ this.game.getMySquad().getPlayer2().getSurname() + ": "+ this.game.getMySquad().getPlayer2().getCondition());
            squad3.setText(this.game.getMySquad().getPlayer3().getName() + " "+ this.game.getMySquad().getPlayer3().getSurname() + ": "+ this.game.getMySquad().getPlayer3().getCondition());
            squad4.setText(this.game.getMySquad().getPlayer4().getName() + " "+ this.game.getMySquad().getPlayer4().getSurname() + ": "+ this.game.getMySquad().getPlayer4().getCondition());
            squad5.setText(this.game.getMySquad().getPlayer5().getName() + " "+ this.game.getMySquad().getPlayer5().getSurname() + ": "+ this.game.getMySquad().getPlayer5().getCondition());
        }
        else{
            bench1.setText(this.game.getOppBench().getPlayer1().getName() + " " + this.game.getOppBench().getPlayer1().getSurname() + ": " + this.game.getOppBench().getPlayer1().getCondition());
            bench2.setText(this.game.getOppBench().getPlayer2().getName() + " " + this.game.getOppBench().getPlayer2().getSurname() + ": " + this.game.getOppBench().getPlayer2().getCondition());
            bench3.setText(this.game.getOppBench().getPlayer3().getName() + " " + this.game.getOppBench().getPlayer3().getSurname() + ": " + this.game.getOppBench().getPlayer3().getCondition());

            squad1.setText(this.game.getOppSquad().getPlayer1().getName() + " "+ this.game.getOppSquad().getPlayer1().getSurname() + ": "+ this.game.getOppSquad().getPlayer1().getCondition());
            squad2.setText(this.game.getOppSquad().getPlayer2().getName() + " "+ this.game.getOppSquad().getPlayer2().getSurname() + ": "+ this.game.getOppSquad().getPlayer2().getCondition());
            squad3.setText(this.game.getOppSquad().getPlayer3().getName() + " "+ this.game.getOppSquad().getPlayer3().getSurname() + ": "+ this.game.getOppSquad().getPlayer3().getCondition());
            squad4.setText(this.game.getOppSquad().getPlayer4().getName() + " "+ this.game.getOppSquad().getPlayer4().getSurname() + ": "+ this.game.getOppSquad().getPlayer4().getCondition());
            squad5.setText(this.game.getOppSquad().getPlayer5().getName() + " "+ this.game.getOppSquad().getPlayer5().getSurname() + ": "+ this.game.getOppSquad().getPlayer5().getCondition());

        }
    }

    @FXML
    private Label out;
    @FXML
    private Label in;
    @FXML
    private Button out1;
    @FXML
    private Button out2;
    @FXML
    private Button out3;
    @FXML
    private Button out4;
    @FXML
    private Button out5;

    @FXML
    private Button in1;
    @FXML
    private Button in2;
    @FXML
    private Button in3;
    @FXML
    private void outting1(){
        if(this.team.getName() == this.game.getMyTeamT().getName()){
            out.setText(this.game.getMySquad().getPlayer1().getName()+ " " + this.game.getMySquad().getPlayer1().getSurname());
            this.change.setPlayerOut(this.game.getMySquad().getPlayer1());
        }
        else{
            out.setText(this.game.getOppSquad().getPlayer1().getName()+ " " + this.game.getOppSquad().getPlayer1().getSurname());
            this.change.setPlayerOut(this.game.getOppSquad().getPlayer1());
        }
    }
    @FXML
    private void outting2(){
        if(this.team.getName() == this.game.getMyTeamT().getName()){
            out.setText(this.game.getMySquad().getPlayer2().getName()+ " " + this.game.getMySquad().getPlayer2().getSurname());
            this.change.setPlayerOut(this.game.getMySquad().getPlayer2());
        }
        else{
            out.setText(this.game.getOppSquad().getPlayer2().getName()+ " " + this.game.getOppSquad().getPlayer2().getSurname());
            this.change.setPlayerOut(this.game.getOppSquad().getPlayer2());
        }
    }
    @FXML
    private void outting3(){
        if(this.team.getName() == this.game.getMyTeamT().getName()){
            out.setText(this.game.getMySquad().getPlayer3().getName()+ " " + this.game.getMySquad().getPlayer3().getSurname());
            this.change.setPlayerOut(this.game.getMySquad().getPlayer3());
        }
        else{
            out.setText(this.game.getOppSquad().getPlayer3().getName()+ " " + this.game.getOppSquad().getPlayer3().getSurname());
            this.change.setPlayerOut(this.game.getOppSquad().getPlayer3());
        }
    }
    @FXML
    private void outting4(){
        if(this.team.getName() == this.game.getMyTeamT().getName()){
            out.setText(this.game.getMySquad().getPlayer4().getName()+ " " + this.game.getMySquad().getPlayer4().getSurname());
            this.change.setPlayerOut(this.game.getMySquad().getPlayer4());
        }
        else{
            out.setText(this.game.getOppSquad().getPlayer2().getName()+ " " + this.game.getOppSquad().getPlayer2().getSurname());
            this.change.setPlayerOut(this.game.getOppSquad().getPlayer2());
        }
    }
    @FXML
    private void outting5(){
        if(this.team.getName() == this.game.getMyTeamT().getName()){
            out.setText(this.game.getMySquad().getPlayer5().getName()+ " " + this.game.getMySquad().getPlayer5().getSurname());
            this.change.setPlayerOut(this.game.getMySquad().getPlayer5());
        }
        else{
            out.setText(this.game.getOppSquad().getPlayer5().getName()+ " " + this.game.getOppSquad().getPlayer5().getSurname());
            this.change.setPlayerOut(this.game.getOppSquad().getPlayer5());
        }
    }

    @FXML
    private void inning1(){
        if(this.team.getName() == this.game.getMyTeamT().getName()){
            in.setText(this.game.getMyBench().getPlayer1().getName() + " " + this.game.getMyBench().getPlayer1().getSurname());
            this.change.setPlayerIn(this.game.getMyBench().getPlayer1());
        }
        else{
            in.setText(this.game.getOppBench().getPlayer1().getName() + " " + this.game.getOppBench().getPlayer1().getSurname());
            this.change.setPlayerIn(this.game.getOppBench().getPlayer1());
        }
    }
    @FXML
    private void inning2(){
        if(this.team.getName() == this.game.getMyTeamT().getName()){
            in.setText(this.game.getMyBench().getPlayer2().getName() + " " + this.game.getMyBench().getPlayer2().getSurname());
            this.change.setPlayerIn(this.game.getMyBench().getPlayer2());
        }
        else{
            in.setText(this.game.getOppBench().getPlayer2().getName() + " " + this.game.getOppBench().getPlayer2().getSurname());
            this.change.setPlayerIn(this.game.getOppBench().getPlayer2());
        }
    }
    @FXML
    private void inning3(){
        if(this.team.getName() == this.game.getMyTeamT().getName()){
            in.setText(this.game.getMyBench().getPlayer3().getName() + " " + this.game.getMyBench().getPlayer3().getSurname());
            this.change.setPlayerIn(this.game.getMyBench().getPlayer3());
        }
        else{
            in.setText(this.game.getOppBench().getPlayer3().getName() + " " + this.game.getOppBench().getPlayer3().getSurname());
            this.change.setPlayerIn(this.game.getOppBench().getPlayer3());
        }
    }

    @FXML
    private Button doChange;
    @FXML
    public void makeChange(){
        this.change.makeChange();
    }

    @FXML
    private Button backButton;
    @FXML
    public void goBackGame(){
        this.gameController.setGame(this.game);
        backButton.getScene().getWindow().hide();
    }
}
